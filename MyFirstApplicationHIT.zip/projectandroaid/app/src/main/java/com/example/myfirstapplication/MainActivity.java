package com.example.myfirstapplication;

import static com.example.myfirstapplication.R.id.textViewResult;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String op = "+";
    String oldNumber= "";
    boolean isOp=true;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.textViewResult);
    }

    public void buttonClickFunction(View view) {

        String op="+";
        if(isOp)
            result.setText("");
        isOp=false;
        String number=result.getText().toString();
        switch(view.getId()){
            case R.id.buttonZero:
                number+= "0";
                break;
            case R.id.buttonOne:
                number+= "1";
                break;
            case R.id.buttonTwo:
                number+= "2";
                break;
            case R.id.buttonThree:
                number+= "3";
                break;
            case R.id.buttonFour:
                number+= "4";
                break;
            case R.id.buttonFive:
                number+= "5";
                break;
            case R.id.buttonSix:
                number+= "6";
                break;
            case R.id.buttonSeven:
                number+= "7";
                break;
            case R.id.buttonEight:
                number+= "8";
                break;
            case R.id.buttonNine:
                number+= "9";
                break;
        }
        result.setText(number);


    }

    public void operatorEvent(View view) {
        isOp = true;
        oldNumber=result.getText().toString();
        switch (view.getId())
        {
            case R.id.buttonDivide: op = "/";break;
            case R.id.buttonPlus: op = "+";break;
            case R.id.buttonMinus: op = "-";break;
            case R.id.buttonMult: op = "*";break;
        }

    }

    public void equalEvent(View view) {
        String newNumber = result.getText().toString();
        double res = 0.0;
        switch (op)
        {
            case "+":
                res=Double.parseDouble(oldNumber)+Double.parseDouble(newNumber);
                break;
            case "-":
                res=Double.parseDouble(oldNumber)-Double.parseDouble(newNumber);
                break;
            case "*":
                res=Double.parseDouble(oldNumber)*Double.parseDouble(newNumber);
                break;
            case "/":
                res=Double.parseDouble(oldNumber)/Double.parseDouble(newNumber);
                break;

        }
        result.setText(res+"");
    }

    public void DeleteEvent(View view) {
        result.setText("0");
        isOp=true;
    }
}